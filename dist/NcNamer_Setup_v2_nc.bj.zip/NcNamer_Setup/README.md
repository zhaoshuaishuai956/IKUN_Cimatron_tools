# NcNamer 自动命名插件 · 多版本一键安装包

Cimatron BJ 后处理完成后，自动把 NC 程序重命名为 `序号-刀名-最小刀长 nc.bj`（如 `03-D10-72 nc.bj`），刀长取 Cimatron 实时数据并经四重校验，无需任何手工点击。

> **v2 变更**：文件名在末尾 `nc` 后增加 `.bj` 后缀（`01-D10-72 nc` → `01-D10-72 nc.bj`）。
> v1（无扩展名的 `空格 + nc`）已存档在 `archive/v1_无扩展名_nc_20261029_1400.zip`。
> 带图标实验代码的 v2 已存档在 `archive/v2_图标实验版_20261029_1606.zip`。
>
> 说明：曾尝试为插件命令配置自定义图标，经多轮排查确认文件、格式转换与 Cimatron 图像加载链路均正常，问题出在其界面模型/图片绑定环节，无法在插件侧解决，故**不再使用自定义图标**，命令沿用 Cimatron 默认图标。安装/卸载时会自动清除早期版本遗留的 `NcNamer_icon*` 文件。

## 一键安装

1. 把整个 `NcNamer_Setup` 文件夹拷贝到目标电脑（U盘 / 网络共享均可）。
2. 右键以管理员身份运行 `安装.cmd`（会自动请求提权）。
3. 脚本会自动探测本机所有 Cimatron 安装并逐个安装；结束后按提示**重启 Cimatron** 即可生效。
4. 卸载：以管理员身份运行 `卸载.cmd`（会移除注册与钩子，原始 BJ.BAT 备份在 `%USERPROFILE%\NcNamer\backup_时间戳`）。

支持参数（可在 PowerShell 中直接运行 install.ps1）：

| 参数 | 作用 |
| --- | --- |
| `-OnlyVersion 2025` | 只处理指定版本 |
| `-AutoLoadOff` | 注册条目使用 @0（默认 @1 自动加载） |
| `-Uninstall` | 卸载 |

## 版本支持矩阵

| 版本 | 自动命名 | 实现方式 |
| --- | --- | --- |
| Cimatron 2024 / 2025 / 2026 | 支持 | 后台插件实时导出 XML + NcPostRename.exe |
| Cimatron E11 及更早 | 暂不支持 | 无插件框架，且 GPP1 后处理无最小刀长变量，无法保证刀长准确（fail-closed 原则，宁可不命名不写错名） |

E11 的可选出路：把 BJ 后处理迁移到 GPP2（ex2），用 `XML_MIN_CLEAR_LEN` 直出刀长，需要现场开发验证。

## 安装内容（每个版本）

- `Program\NcNamerAutoService.dll`：后台插件，Cimatron 启动时自动加载（优先现场编译，失败回退包内预编译版），无自定义图标。
- `ExternalCommands.ini`：注册一条外部命令（自动去重、保留原文件备份）。
- 后处理目录（`It\var\post`、`Nc\MachineWorks\post`、`SourceData\It\var\post`）：
  - `NcPostRename.exe`：命名器。
  - `BJ.BAT` / `BJ.CMD`：追加一行 `start "" /min "%~dp0NcPostRename.exe"`（原内容保留）。
  - `BJ.EXF`：若没有 NCMETA，则在 `BEGINNING OF PROC:` 后注入 `OUTPUT $ "( NCMETA PROC=" PROC_NUM " )" ;` 并用该版本的 `dfexf` 重新编译 `bj.dex`。

## 命名规则（详见 NC命名规则.png）

- 文件名：`序号-刀名-最小刀长 nc.bj`（v2；末尾为空格 + nc + `.bj` 扩展名；无刀长要求时刀长段为 `NA`）。
- 序号：输出目录已有最大序号 +1，两位显示，重名顺延。
- 刀名：XML「刀具_夹持」清洗后（`.`→`d`，非法字符→`_`，限 80 字符，空则 NO_TOOL）。
- 最小刀长：XML「最小有效长度」向上取整。
- **无最小伸出要求时记 NA**：Cimatron 用 `-1`（刀长足够/忽略夹持）、`-2`（不适用）、`0` 表示该程序没有最小伸出要求，此时文件名刀长段记 `NA` 并继续命名（如 `06-QTECH12-NA nc.bj`），不再放弃。若希望这种情况干脆不命名，设置环境变量 `NCNAMER_LEN_ZERO_AS_FAIL=1`（严格模式）。
- 校验：唯一令牌、程序号比对、XML 时间戳新鲜度（不早于本次请求）、SHA256 一致，四重全过才采用。
- 失败保护：任一环节失败 → 保留原 NC 文件 + 生成 `NC_RENAME_FAILED.txt` 说明原因（超时上限 180 秒）。

## 日志与排查

- `%USERPROFILE%\NcNamer\auto_service_log.txt`：插件取数日志。
- `%USERPROFILE%\NcNamer\post_rename_log.txt`：命名器日志（每次运行覆盖）。
- `%USERPROFILE%\NcNamer\install_report.txt`：最近一次安装报告。
- `%USERPROFILE%\NcNamer\backup_时间戳\`：安装前自动备份（ini / dll / exe / exf / 原钩子）。

## 目录结构

```
NcNamer_Setup\
  安装.cmd            一键安装（自动提权）
  卸载.cmd            一键卸载
  install.ps1         安装核心逻辑（多版本探测 / 编译 / 注册 / 部署）
  NC命名规则.png      命名规则说明图（v2）
  payload\
    common\NcPostRename.exe        命名器（通用，含 GPP 直出兼容，v2 输出 .bj）
    plugins\prebuilt_*.dll         2024/2025 预编译插件（现场编译失败时回退）
    src\NcNamerAutoService.cs      插件源码（安装时按目标版本现场编译）
    src\NcPostRenameAuto.cs        命名器源码
```
